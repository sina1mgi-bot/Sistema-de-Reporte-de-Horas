public class JefeDepartamento extends Usuario{
    //no tiene atributos extras
    public JefeDepartamento(String nombre, String psww) {
        super(nombre, psww);
    }
}
