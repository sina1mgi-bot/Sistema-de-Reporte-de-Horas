import java.util.List;
import java.util.Date;

public class Proyecto {
    private String nombre;
    private String empresa;
    private int numParticipantes;
    private List<Estudiante> estudiantesAsignados;
    private String actividades;
    private Date fechaInicio;
    private Date fechaFin;


}
